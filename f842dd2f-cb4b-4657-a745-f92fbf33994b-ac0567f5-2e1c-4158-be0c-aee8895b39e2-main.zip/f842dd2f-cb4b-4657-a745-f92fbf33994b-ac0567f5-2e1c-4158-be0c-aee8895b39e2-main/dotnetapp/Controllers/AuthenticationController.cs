using Microsoft.AspNetCore.Mvc;
using dotnetapp.Models;
using dotnetapp.Services;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/")]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthenticationController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { Message = "Invalid login request." });

            var (statusCode, responseMessage) = await _authService.SendOtp(model);
            if (statusCode == 1)
                return Ok(new { Message = responseMessage });
            return Unauthorized(new { Message = responseMessage });
        }

        //Otp is verifying here
        [HttpPost("verify-otp")]
        public async Task<IActionResult> VerifyOtp([FromBody] OtpModel model)
        {
            var (statusCode, responseMessage) = await _authService.VerifyOtp(model.Email, model.Otp);
            if (statusCode == 1)
            {
                var (loginStatus, tokenOrMsg) = await _authService.Login(new LoginModel { Email = model.Email });
                if (loginStatus == 1)
                    return Ok(new { token = tokenOrMsg });
                return Unauthorized(new { Message = tokenOrMsg });
            }
            return Unauthorized(new { Message = responseMessage });
        }
        //registering here

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User model)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { Message = "Invalid registration request." });

            var (statusCode, responseMessage) = await _authService.SendRegistrationOtp(model);
            if (statusCode == 1)
                return Ok(new { Message = responseMessage });
            return BadRequest(new { Message = responseMessage });
        }

        [HttpPost("verify-registration-otp")]
        public async Task<IActionResult> VerifyRegistrationOtp([FromBody] OtpModel model)
        {
            var (statusCode, responseMessage) = await _authService.VerifyRegistrationOtp(model.Email, model.Otp);
            if (statusCode == 1)
                return Ok(new { Message = responseMessage });
            return BadRequest(new { Message = responseMessage });
        }


        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var (status, message) = await _authService.ForgotPassword(model.Email);
            if (status == 0)
                return BadRequest(new { Message = message });

            return Ok(new { Message = message });
        }


        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordModel newmodel)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (newmodel.NewPassword != newmodel.ConfirmPassword)
                return BadRequest(new { Message = "Passwords do not match." });

            // var (status, message) = await _authService.ResetPassword(model.Email, model.NewPassword, model.Token);

            (int status, string message) = await _authService.ResetPassword(newmodel.Email , newmodel.NewPassword , newmodel.Token);

            if (status == 0)
                return BadRequest(new { Message = message });

            return Ok(new { Message = message });
        }


                // [HttpPost("reset-password")]
        // public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordModel model, [FromQuery] string token)
        // {
        //     if (!ModelState.IsValid)
        //         return BadRequest(ModelState);

        //     if (model.NewPassword != model.ConfirmPassword)
        //         return BadRequest(new { Message = "Passwords do not match." });

        //     var (status, message) = await _authService.ResetPassword(model.Email, model.NewPassword, token);
        //     if (status == 0)
        //         return BadRequest(new { Message = message });

        //     return Ok(new { Message = message });
        // }





    }
}
