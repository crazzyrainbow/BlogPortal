using dotnetapp.Models;
using System.Threading.Tasks;

namespace dotnetapp.Services
{
    public interface IAuthService
    {   
        Task<(int,string)> SendRegistrationOtp(User model);
        Task<(int,string)> VerifyRegistrationOtp(string email,string otp);
        Task<(int,string)> Login(LoginModel model);
        Task<(int,string)> SendOtp(LoginModel model);
        Task<(int,string)> VerifyOtp(string email, string otp);
        Task<(int, string)> ForgotPassword(string email);
        Task<(int, string)> ResetPassword(string email, string newPassword, string token);

    }
}
