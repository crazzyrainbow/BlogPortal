
export const environment = {
  production: false,

  apiUrl: 'https://8080-eeedddfffacdfeccdaabfffbfcacfecbecaeebe.project.examly.io',

  //use this 
  Akey:'AA3B4C'
};
 


