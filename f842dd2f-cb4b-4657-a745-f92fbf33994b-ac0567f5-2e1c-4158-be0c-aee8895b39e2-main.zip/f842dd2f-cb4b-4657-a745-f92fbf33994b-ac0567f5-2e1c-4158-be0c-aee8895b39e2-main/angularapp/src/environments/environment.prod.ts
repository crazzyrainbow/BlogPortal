export const environment = {
  production: true,
  apiUrl: 'https://8080-bcaabfcadeececdaabfffbfcacfecbecaeebe.project.examly.io',
};