import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BlogPost } from 'src/app/models/blog-post.model';
import { BlogPostService } from 'src/app/services/blog-post.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-add-blog',
  templateUrl: './user-add-blog.component.html',
  styleUrls: ['./user-add-blog.component.css']
})
export class UserAddBlogComponent implements OnInit {
  blogPost: BlogPost = {
    UserId: 0,
    Title: '',
    Content: '',
    Status: '',
    PublishedDate: new Date()
  };
  submitted = false;
  errorMessage = '';
  isEditMode = false;
  blogIdToEdit: number | null = null;

  constructor(
    private blogService: BlogPostService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.isEditMode = true;
        this.blogIdToEdit = +id;
        this.blogService.getBlogPostById(this.blogIdToEdit).subscribe({
          next: (data) => {
            this.blogPost = data;
          },
          error: (err) => {
            console.error('Error fetching blog:', err);
          }
        });
      }
    });
  }

  onSubmit(form: any): void {
    this.submitted = true;
    this.errorMessage = '';

    if (form.invalid) {
      this.errorMessage = 'Please fill in all required fields.';
      return;
    }

    const trimmedTitle = this.blogPost.Title.trim();
    const trimmedContent = this.blogPost.Content.trim();

    if (!trimmedTitle || !trimmedContent) {
      this.errorMessage = 'Title and Content cannot be empty or just spaces.';
      return;
    }

    const updatedBlog: BlogPost = {
      ...this.blogPost,
      UserId: parseInt(localStorage.getItem('userId') || '0', 10),
      Title: trimmedTitle,
      Content: trimmedContent,
      Status: this.isEditMode ? this.blogPost.Status : 'Pending',
      PublishedDate: this.isEditMode ? this.blogPost.PublishedDate : new Date()
    };

    if (this.isEditMode && this.blogIdToEdit !== null) {
      this.blogService.updateBlogPost(this.blogIdToEdit, updatedBlog).subscribe({
        next: () => {
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'Blog Post Updated Successfully!',
            confirmButtonColor: '#3085d6'
          });
          this.router.navigate(['/userviewblog']);
        },
        error: () => {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An error occurred while updating the blog post',
            confirmButtonColor: '#d33'
          });
        }
      });
    } else {
      this.blogService.addBlogPost(updatedBlog).subscribe({
        next: () => {
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'Blog Post Added Successfully!',
            confirmButtonColor: '#3085d6'
          });
          this.router.navigate(['/userviewblog']);
        },
        error: (error) => {
          if (error.status === 400 || error.error === 'Blog with this title already exists') {
            Swal.fire({
              icon: 'warning',
              title: 'Duplicate Title',
              text: 'A blog with the title already exists',
              confirmButtonColor: '#f39c12'
            });
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'An error occurred while adding the blog post',
              confirmButtonColor: '#d33'
            });
          }
        }
      });
    }
  }
}
