import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { Login } from 'src/app/models/login.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: Login = new Login();
  loginError: string | null = null;
  loginSuccess: boolean = false;
  passwordFieldType: string = 'password';
  confirmPasswordFieldType: string = 'password';

  otpVerificationRequired: boolean = false;
  userOtp: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {}

  login(loginForm: any): void {
    if (!loginForm.valid) {
      this.loginError = 'Please fill in all required fields correctly.';
      return;
    }

    if (!this.validateEmail(this.user.Email)) {
      this.loginError = 'Invalid email format';
      return;
    }

    if (!this.user.Password || this.user.Password.trim().length < 6) {
      this.loginError = 'Password must be at least 6 characters long';
      return;
    }

    this.authService.requestLoginOtp(this.user).subscribe(
      response => {
        console.log('OTP sent successfully', response);
        Swal.fire('Success', 'OTP sent to your email', 'success');
        this.loginError = null;
        this.otpVerificationRequired = true;
      },
      error => {
        console.error('Error requesting OTP', error);
        this.loginError = error.error?.Message || 'Failed to send OTP. Please try again.';
      }
    );
  }

  verifyOtp(): void {
    if (!this.user.Email) {
      this.loginError = 'Email is required for OTP verification';
      return;
    }
    if (!this.userOtp) {
      this.loginError = 'Please enter the OTP sent to your email';
      return;
    }

    const payload = { email: this.user.Email, otp: this.userOtp };
    this.authService.verifyLoginOtp(payload).subscribe(
      response => {
        console.log('OTP verified successfully', response);
        Swal.fire('Success', 'Login successful', 'success');
        this.loginError = null;
        this.loginSuccess = true;
        this.router.navigate(['/home']);
      },
      error => {
        console.error('OTP verification error', error);
        this.loginError = error.error?.Message || 'OTP verification failed. Please try again.';
      }
    );
  }

  resetLoginError(): void {
    this.loginError = null;
    this.loginSuccess = false;
  }

  register(): void {
    this.router.navigate(['/register']);
  }

  validateEmail(email: string): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailRegex.test(email);
  }

  togglePasswordVisibility(field: string): void {
    if (field === 'password') {
      this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
    } else if (field === 'confirmPassword') {
      this.confirmPasswordFieldType = this.confirmPasswordFieldType === 'password' ? 'text' : 'password';
    }
  }
}
