import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/services/feedback.service';
import { Feedback } from 'src/app/models/feedback.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-admin-view-feedback',
  templateUrl: './admin-view-feedback.component.html',
  styleUrls: ['./admin-view-feedback.component.css']
})
export class AdminViewFeedbackComponent implements OnInit {
  feedbacks: Feedback[] = [];
  columnDefs: any;
  defaultColDef: any;
  itemsPerPage: number = 5;

  constructor(private feedbackService: FeedbackService) {}

  ngOnInit(): void {
    this.loadFeedbacks();

    this.columnDefs = [
      { headerName: 'Username', field: 'User.Username', sortable: true, filter: true },
      { headerName: 'Email', field: 'User.Email', sortable: true, filter: true },
      { headerName: 'Mobile Number', field: 'User.MobileNumber', sortable: true, filter: true },
      { headerName: 'Message', field: 'FeedbackText', sortable: true, filter: true },
      {
        headerName: 'Actions',
        cellRenderer: (params: any) => {
          const button = document.createElement('button');
          button.innerText = 'View Profile';
          button.className = 'btn btn-sm btn-info';
          button.onclick = () => {
            const { Username, Email, MobileNumber } = params.data.User;
            this.showProfile(Username, Email, MobileNumber);
          };
          return button;
        }
      }
    ];

    this.defaultColDef = {
      resizable: true,
      filter: true,
      sortable: true
    };
  }

  loadFeedbacks(): void {
    this.feedbackService.getFeedbacks().subscribe({
      next: (data) => {
        this.feedbacks = data;
        console.log('Loaded feedbacks:', this.feedbacks); // Debug log
      },
      error: () => console.error('Failed to load feedbacks')
    });    
  }

  showProfile(username: string, email: string, mobile: string): void {
    Swal.fire({
      title: 'User Profile',
      html: `
        <p><strong>Username:</strong> ${username}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Mobile Number:</strong> ${mobile}</p>
      `,
      icon: 'info'
    });
  }
}
