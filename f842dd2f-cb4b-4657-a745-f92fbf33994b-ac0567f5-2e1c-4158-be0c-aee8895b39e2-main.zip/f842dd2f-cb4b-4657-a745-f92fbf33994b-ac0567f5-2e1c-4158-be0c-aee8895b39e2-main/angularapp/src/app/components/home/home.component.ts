
import { Component, OnInit, AfterViewInit } from '@angular/core';
import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';
import { AuthService } from 'src/app/services/auth.service';

gsap.registerPlugin(ScrollTrigger);

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit {
  role: string;
  isAdmin: boolean = false;
  username: string;
  constructor(private authService:AuthService){}
  ngOnInit(): void {
    this.role = localStorage.getItem('userRole');
    const userInfo = this.authService.getUserInfo();
    this.username = userInfo.username;
  }

  ngAfterViewInit(): void {

    // Animate cards
  
    gsap.utils.toArray('.step').forEach((step: any, index: number) => {
      gsap.to(step, {
        scrollTrigger: {
          trigger: step,
          start: 'top 85%',
          toggleActions: 'play none none none'
        },
        opacity: 1,
        y: 0,
        duration: 0.6,
        delay: index * 0.1,
        ease: 'power3.out',
      });
    });
    gsap.utils.toArray('.card').forEach((card: any, index: number) => {
  
      gsap.fromTo(card,
  
        { opacity: 0, y: 50, scale: 0.95 },
  
        {
  
          scrollTrigger: {
  
            trigger: card,
  
            start: 'top 85%',
  
            toggleActions: 'play none none none',
  
          },
  
          opacity: 1,
  
          y: 0,
  
          scale: 1,
  
          duration: 0.6,
  
          delay: index * 0.1,
  
          ease: 'power3.out',
  
        });
  
    });
  
    // Stat counters (0 to value)
  
    // Stat Counters with K+ suffix (fixed version)
const counters = document.querySelectorAll('.count');
counters.forEach((counter: any) => {
 const finalValue = +counter.getAttribute('data-count');
 const obj = { count: 0 };
 gsap.to(obj, {
   count: finalValue,
   duration: 2,
   ease: 'power1.out',
   scrollTrigger: {
     trigger: counter,
     start: 'top 80%',
     toggleActions: 'play none none none',
   },
   onUpdate: () => {
     let val = obj.count;
     if (finalValue >= 1000) {
       counter.innerText = (val / 1000).toFixed(1) + 'K+';
     } else {
       counter.innerText = Math.floor(val) + '+';
     }
   }
 });
});
  
  }  
}


