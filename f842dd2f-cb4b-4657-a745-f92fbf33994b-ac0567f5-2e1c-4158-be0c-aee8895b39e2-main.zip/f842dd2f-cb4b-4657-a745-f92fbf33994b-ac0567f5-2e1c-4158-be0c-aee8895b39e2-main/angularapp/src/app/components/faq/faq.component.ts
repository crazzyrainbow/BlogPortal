import { Component } from '@angular/core';
 
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent {
  searchQuery: string = '';
 
  faqs = [
    {
      question: 'What is BlogPortal?',
      answer: 'BlogPortal is a platform where you can create, view, and share blogs.',
      showAnswer: false
    },
    {
      question: 'How do I create a blog?',
      answer: 'To create a blog, go to the "Create Blog" section and fill out the form.',
      showAnswer: false
    },
    {
      question: 'How can I view announcements?',
      answer: 'You can view announcements in the "View Announcements" section.',
      showAnswer: false
    },
    {
      question: 'How do I create a new account?',
      answer: 'Click on the "Register" or "Sign Up" button on the login page. Fill in the required details and submit the form to create your account.',
      showAnswer: false
    },
    {
      question: 'Can I update my profile after registration?',
      answer: 'Yes, go to your profile section after logging in and click on "Edit Profile" to update your details.',
      showAnswer: false
    },
    {
      question: 'What should I do if I forget my password?',
      answer: 'Click on "Forgot Password" on the login page. Enter your registered email, verify using the OTP sent, and set a new password.',
      showAnswer: false
    },
    {
      question: 'How can I contact support?',
      answer: 'You can reach us via the "Contact Us" page or by emailing support@yourdomain.com.',
      showAnswer: false
    },
    {
      question: 'Is my personal data secure on this platform?',
      answer: 'Yes, we use industry-standard encryption and security practices to protect your personal data.',
      showAnswer: false
    },
    {
      question: 'Why am I not receiving verification emails or OTPs?',
      answer: 'Please check your spam or junk folder. Also, ensure that your email address is correct and your inbox isn\'t full.',
      showAnswer: false
    },
    {
      question: 'Which browsers are supported for the best experience?',
      answer: 'We recommend using the latest version of Chrome, Firefox, Microsoft Edge, or Safari.',
      showAnswer: false
    },
    {
      question: 'Can I access the platform on mobile devices?',
      answer: 'Yes, our platform is responsive and works well on both mobile phones and tablets.',
      showAnswer: false
    },
    {
      question: 'How do I clear my browser cache to resolve issues?',
      answer: 'Go to your browser settings → Privacy & Security → Clear browsing data → Select “Cached images and files” and clear it.',
      showAnswer: false
    },
    {
      question: 'What do I do if the site is loading slowly or not at all?',
      answer: 'Try refreshing the page or clearing your cache. If the issue persists, check your internet connection or contact support.',
      showAnswer: false
    },
    {
      question: 'How do I manage or add new users as an admin?',
      answer: 'Go to the Admin Dashboard and navigate to the "Users" section. From there, you can view, add, or manage users.',
      showAnswer: false
    },
    {
      question: 'Can I assign specific roles to users?',
      answer: 'Yes, while adding a new user or editing an existing one, you can select a role such as Admin, Organizer, or User.',
      showAnswer: false
    },
    {
      question: 'Where can I view system activity or logs?',
      answer: 'Go to the Admin Panel and click on “Activity Logs” or “System Logs” to monitor user activity and system events.',
      showAnswer: false
    },
    {
      question: 'How do I reset another user\'s password?',
      answer: 'Navigate to the user’s profile in the admin panel and click on “Reset Password.” An email with a reset link will be sent to the user.',
      showAnswer: false
    },
    {
      question: 'What should I do if I suspect unauthorized access to my account?',
      answer: 'Immediately change your password and contact support to report the incident.',
      showAnswer: false
    },
    {
      question: 'How frequently should I change my password?',
      answer: 'It’s recommended to update your password every 3 to 6 months for enhanced security.',
      showAnswer: false
    },
    {
      question: 'How is my data protected on this platform?',
      answer: 'We use SSL encryption, secure database practices, and regular security audits to ensure your data stays safe.',
      showAnswer: false
    }
  ];
 
  toggleAnswer(faq: any): void {
    faq.showAnswer = !faq.showAnswer;
  }
 
  filteredFaqs(): any[] {
    const query = this.searchQuery.toLowerCase();
    return this.faqs.filter(faq =>
      faq.question.toLowerCase().includes(query)
    );
  }
}