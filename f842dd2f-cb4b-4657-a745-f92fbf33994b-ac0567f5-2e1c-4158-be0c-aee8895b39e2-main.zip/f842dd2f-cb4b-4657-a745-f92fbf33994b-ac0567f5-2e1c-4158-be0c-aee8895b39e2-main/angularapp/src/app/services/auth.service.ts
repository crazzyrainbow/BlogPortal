import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { Login } from '../models/login.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public apiUrl = environment.apiUrl;
  private currentUserRole = new BehaviorSubject<string | null>(null);

  constructor(private http: HttpClient) {
    const token = localStorage.getItem('token');
    if (token) {
      this.currentUserRole.next(this.getUserRoleFromToken(token));
    }
  }


  requestLoginOtp(credentials: Login): Observable<any> {
 
    return this.http.post<any>(`${this.apiUrl}/api/login`, credentials);
  }

 
  verifyLoginOtp(data: { email: string; otp: string }): Observable<any> {
    return new Observable(observer => {
      this.http.post<any>(`${this.apiUrl}/api/verify-otp`, data).subscribe(
        response => {
          if (response.token) {
            const token = response.token;
            localStorage.setItem('token', token);

            const role = this.getUserRoleFromToken(token);
            const userId = this.getUserIdFromToken(token);
            const userName = this.getUserNameFromToken(token);
            const userEmailAddress = this.getUserEmailFromToken(token);
          

            localStorage.setItem('userRole', role);
            localStorage.setItem('userId', userId);
            localStorage.setItem('userName', userName);
            localStorage.setItem('userEmailAddress', userEmailAddress);
            
            this.currentUserRole.next(role);
          }
          observer.next(response);
          observer.complete();
        },
        error => observer.error(error)
      );
    });
  }

  forgotPassword(email: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/forgot-password`, { email }, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  resetPassword(data: {
    email: string;
    newPassword: string;
    confirmPassword: string;
    token: string;
  }): Observable<any> {
    return this.http.post<any>(
      `${this.apiUrl}/api/reset-password`, // ✅ Removed query param
      {
        email: data.email,
        newPassword: data.newPassword,
        confirmPassword: data.confirmPassword,
        token: data.token // ✅ Include token in body
      },
      {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' })
      }
    );
  }
  

  // resetPassword(data: {
  //   email: string;
  //   newPassword: string;
  //   confirmPassword: string;
  //   token: string;
  // }): Observable<any> {
  //   return this.http.post<any>(
  //     `${this.apiUrl}/api/reset-password?token=${data.token}`,
  //     {
  //       email: data.email,
  //       newPassword: data.newPassword,
  //       confirmPassword: data.confirmPassword
  //     },
  //     {
  //       headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  //     }
  //   );
  // }
  
  
  




  register(user: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/register`, user, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }

  verifyRegistrationOtp(data: { email: string; otp: string }): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/api/verify-registration-otp`, data, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    });
  }


  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  logout(): void {
    localStorage.clear();
    this.currentUserRole.next(null);
  }

  getUserRole(): string | null {
    return localStorage.getItem('userRole');
  }
  getUserId(){
    return localStorage.getItem('userId');
  }
  getUserName(){
    return localStorage.getItem('userName');
  }
  getEmailAddress(){
    return localStorage.getItem('userEmailAddress');
  }

  setUserRole(role: string): void {
    localStorage.setItem('userRole', role);
  }

  getUserEmailFromToken(token: string): string | null {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"];
    } catch (error) {
      console.error("Error decoding token email address:", error);
      return null;
    }
  }

  getUserRoleFromToken(token: string): string | null {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
    } catch (error) {
      console.error("Error decoding token role:", error);
      return null;
    }
  }

  getUserIdFromToken(token: string): string | null {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"];
    } catch (error) {
      console.error("Error decoding token userId:", error);
      return null;
    }
  }

  getUserNameFromToken(token: string): string | null {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"];
    } catch (error) {
      console.error("Error decoding token userName:", error);
      return null;
    }
  }

  getCurrentUserRole(): Observable<string | null> {
    return this.currentUserRole.asObservable();
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isAdmin(): boolean {
    return this.getUserRole() === 'Admin';
  }

  isUser(): boolean {
    return this.getUserRole() === 'User';
  }
  getUserInfo(): { id: number, username: string } {
    return {
      id: +localStorage.getItem('userId'),
      username: localStorage.getItem('userName') || ''
    };
  }
}
