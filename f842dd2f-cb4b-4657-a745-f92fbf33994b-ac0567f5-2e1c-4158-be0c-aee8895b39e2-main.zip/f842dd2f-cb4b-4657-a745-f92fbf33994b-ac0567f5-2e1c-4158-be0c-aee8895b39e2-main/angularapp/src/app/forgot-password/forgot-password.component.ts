
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {
  emailForm: FormGroup;
  resetForm: FormGroup;
  emailSubmitted = false;
  successMessage: string = '';
  errorMessage: string = '';
  resetVisible: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.emailForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });

    this.resetForm = this.fb.group({
      token: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordsMatchValidator });
  }

  passwordsMatchValidator(form: FormGroup) {
    return form.get('newPassword')?.value === form.get('confirmPassword')?.value
      ? null : { mismatch: true };
  }

  onEmailSubmit(): void {
    this.emailSubmitted = true;
    this.successMessage = '';
    this.errorMessage = '';

    if (this.emailForm.invalid) return;

    this.authService.forgotPassword(this.emailForm.value.email).subscribe({
      next: () => {
        this.successMessage = 'Password reset link has been sent to your email.';
        this.resetVisible = true;
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Something went wrong.';
      }
    });
  }

  onResetSubmit(): void {
    if (this.resetForm.invalid) return;

    const data = {
      email: this.emailForm.value.email,
      token: this.resetForm.value.token,
      newPassword: this.resetForm.value.newPassword,
      confirmPassword: this.resetForm.value.confirmPassword
    };

    this.authService.resetPassword(data).subscribe({
      next: () => {
        this.successMessage = 'Password has been successfully updated.';
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Failed to reset password.';
      }
    });
  }
}
