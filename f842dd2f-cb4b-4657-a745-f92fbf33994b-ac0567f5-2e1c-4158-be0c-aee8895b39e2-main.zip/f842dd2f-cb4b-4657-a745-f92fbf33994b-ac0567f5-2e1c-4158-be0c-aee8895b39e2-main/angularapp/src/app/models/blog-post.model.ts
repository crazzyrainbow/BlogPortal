export class BlogPost{
    BlogPostId?:number;
    UserId:number;
    Title:string;
    Content:string;
    Status:string;
    PublishedDate:Date;
}