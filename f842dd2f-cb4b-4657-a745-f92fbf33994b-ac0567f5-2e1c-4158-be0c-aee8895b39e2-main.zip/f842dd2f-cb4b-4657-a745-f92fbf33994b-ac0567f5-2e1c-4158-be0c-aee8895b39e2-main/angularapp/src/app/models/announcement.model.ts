export class Announcement {
    AnnouncementId?: number;
    Title: string;
    Content: string;
    PublishedDate: Date;
    Category: string;
    Priority: string;
    Status: string;
}