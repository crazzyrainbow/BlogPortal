# f842dd2f-cb4b-4657-a745-f92fbf33994b-ac0567f5-2e1c-4158-be0c-aee8895b39e2
https://sonar.server.examly.io/dashboard?id=iamneo-production_f842dd2f-cb4b-4657-a745-f92fbf33994b-ac0567f5-2e1c-4158-be0c-aee8895b39e2&amp;codeScope=overall
